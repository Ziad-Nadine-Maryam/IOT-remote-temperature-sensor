import java.io.*; 
import java.net.*; 
import java.util.ArrayList;

class TCPServer{ 
	static int id = 0 ;
	static ArrayList<MyThread> info ;


	public static void main(String argv[]) throws Exception 
	{ 
		System.out.println("Server is ON......");

		ServerSocket welcomeSocket = new ServerSocket(6789); 

		while(true) { 
			System.out.println("Waiting for connection.......");

			Socket connectionSocket = welcomeSocket.accept(); 

			int x=id+1 ;

			System.out.println("Server is now connected to the Client Number " + x);

			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())); 

			DataOutputStream  outToClient = new DataOutputStream(connectionSocket.getOutputStream()); 

			String tmp=id + " " ;

			MyThread t = new MyThread(tmp, inFromClient, outToClient, connectionSocket) ;



			try{
				t.start();
				id++ ;
				info.add(t) ;

			}
			catch(Exception e) {
			

			}




		} 
	} 
} 


