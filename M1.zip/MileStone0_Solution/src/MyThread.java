import java.io.*;
import java.net.*;
public class MyThread extends Thread{
	final String id ; 
	final BufferedReader dis ;
	final DataOutputStream dos ; 
	final Socket s ; 
	String clientSentence ;
	String capitalizedSentence ; 

	public MyThread(String id,BufferedReader dis , DataOutputStream dos ,Socket s) {
		this.id=id ;
		this.dis=dis ; 
		this.dos = dos ; 
		this.s=s ; 

	}
	public void run (){
		while(true){

		try{

			BufferedReader dis = new BufferedReader(new InputStreamReader(s.getInputStream())); 

			DataOutputStream  dos = new DataOutputStream(s.getOutputStream()); 

				clientSentence = dis.readLine(); 

				capitalizedSentence = clientSentence.toUpperCase() + '\n';

				dos.writeBytes(capitalizedSentence); 

				if(clientSentence.equalsIgnoreCase("Close Socket"))
				{
					System.out.println("Connection Socket between the server and client is closed");
					System.out.println("===============================================");
					System.out.println("Server is Still Running......");
					break;
				}
			} 
		catch(Exception e1) {
			e1.printStackTrace();

		}
		}
	}
	

}
